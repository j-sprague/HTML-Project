$(document).ready(function() {
$( function() {
    $( "#accordion" ).accordion(
        {
            collapsible: true,
            active: false
        }
    );
});
});